"""
Outbound Bot Framework Connector API access — the bot's own token, and
sending/updating/deleting a Teams message. Plain synchronous `requests`.

Token acquisition is Managed-Identity-only: this is a production bot, and
the User-Assigned Managed Identity (MANAGED_IDENTITY_CLIENT_ID) is always
available since it's provisioned together with the Function App by
azure/infra/main.bicep — no client secret ever enters this codebase.
Extended here with update/delete since this bot (unlike rs-alerts) edits
and removes its own "looking into that…" placeholder.
"""
import logging
import threading
import time

import requests
from azure.identity import ManagedIdentityCredential
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from app.config import settings
from app.constants import BOT_CONNECTOR_TIMEOUT, TOKEN_EXPIRY_SAFETY_SECONDS

logger = logging.getLogger("gti-teams-bot")

_BOTFRAMEWORK_SCOPE = "https://api.botframework.com/.default"

_session = requests.Session()
# Retry.DEFAULT_ALLOWED_METHODS (the default here, left unset deliberately)
# excludes POST — send_activity() below is the only POST caller, and it
# creates a brand-new message, so retrying it on an ambiguous failure (e.g.
# a 503 where the request may have already been processed) risks double-
# posting to the user. update_activity()/delete_activity() (PUT/DELETE) are
# idempotent and safe to retry, and are covered by the default method set.
_retry_strategy = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=[429, 500, 502, 503, 504],
    raise_on_status=False,
)
_session.mount("https://", HTTPAdapter(max_retries=_retry_strategy))
_bot_token: str | None = None
_bot_token_expires_at: float = 0.0
_token_lock = threading.Lock()


def _fetch_token_via_managed_identity() -> tuple[str, float]:
    """Returns (token, seconds_until_expiry)."""
    credential = ManagedIdentityCredential(client_id=settings.managed_identity_client_id)
    result = credential.get_token(_BOTFRAMEWORK_SCOPE)
    seconds_remaining = max(0.0, result.expires_on - time.time())
    return result.token, seconds_remaining


def get_bot_token() -> str:
    """Return a cached app-only Bot Framework Connector token, refreshing it if near expiry."""
    global _bot_token, _bot_token_expires_at
    if _bot_token and time.monotonic() < _bot_token_expires_at - TOKEN_EXPIRY_SAFETY_SECONDS:
        return _bot_token

    # Azure Functions can run a request pool with more than one worker thread
    # per instance — without this lock, two overlapping requests can both see
    # an expired token above and both refresh it concurrently.
    with _token_lock:
        if _bot_token and time.monotonic() < _bot_token_expires_at - TOKEN_EXPIRY_SAFETY_SECONDS:
            return _bot_token

        if not settings.managed_identity_client_id:
            raise RuntimeError("MANAGED_IDENTITY_CLIENT_ID is not configured.")

        token, seconds_remaining = _fetch_token_via_managed_identity()
        _bot_token = token
        _bot_token_expires_at = time.monotonic() + seconds_remaining
        return _bot_token


def _headers() -> dict:
    return {"Authorization": f"Bearer {get_bot_token()}", "Content-Type": "application/json"}


def send_activity(service_url: str, conversation_id: str, activity: dict) -> dict:
    """POST a new activity to a conversation. Returns the Connector API response (includes 'id')."""
    url = f"{service_url.rstrip('/')}/v3/conversations/{conversation_id}/activities"
    resp = _session.post(url, headers=_headers(), json=activity, timeout=BOT_CONNECTOR_TIMEOUT)
    resp.raise_for_status()
    return resp.json() if resp.content else {}


def update_activity(service_url: str, conversation_id: str, activity_id: str, activity: dict) -> dict:
    """PUT (edit in place) an existing activity."""
    url = f"{service_url.rstrip('/')}/v3/conversations/{conversation_id}/activities/{activity_id}"
    resp = _session.put(url, headers=_headers(), json=activity, timeout=BOT_CONNECTOR_TIMEOUT)
    resp.raise_for_status()
    return resp.json() if resp.content else {}


def delete_activity(service_url: str, conversation_id: str, activity_id: str) -> None:
    """DELETE an existing activity."""
    url = f"{service_url.rstrip('/')}/v3/conversations/{conversation_id}/activities/{activity_id}"
    resp = _session.delete(url, headers=_headers(), timeout=BOT_CONNECTOR_TIMEOUT)
    resp.raise_for_status()
