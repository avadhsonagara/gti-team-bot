"""
Core RS Alerts job: fetch incremental GTI alerts and deliver them to Teams.

Flow:
  1. Load the cursor (last seen ``audit.update_time``) from blob state.
       - First run / no state -> fetch the entire alert history (no lower bound).
  2. Ensure the bot's Teams app is installed in the target team (Microsoft
     Graph auto-install — only possible when TEAMS_CHANNEL_ID is the full
     channel link, since that's what carries the team id).
  3. Exchange the GTI API key for a short-lived bearer token.
  4. Call List Alerts with a filter combining the cursor AND the level
     filters, ordered by ``audit.update_time asc``, paginating through all
     pages.
  5. For each alert, post an Adaptive Card (v1.4) to the Teams channel via
     the Bot Framework Connector API, checkpointing the cursor after every
     successful send.
"""
import logging

from app.config import Settings
from app.graph_client import ensure_app_installed
from app.gti_client import build_filter, get_gti_access_token, list_alerts
from app.sender import AlertSender, extract_channel_id, extract_team_id
from app.state_store import read_cursor, write_cursor

logger = logging.getLogger("rs-alerts")


def _validate_settings(settings: Settings) -> str:
    """Validate required configuration and return the canonical Teams channel ID."""
    missing = [
        name for name, val in (
            ("TEAMS_CHANNEL_ID", settings.teams_channel_id),
            ("GTI_API_KEY", settings.gti_api_key),
            ("GTI_RSA_PROJECT", settings.gti_rsa_project),
        ) if not val
    ]
    if missing:
        raise RuntimeError(f"Missing required environment variable(s): {', '.join(missing)}")

    if not settings.managed_identity_client_id:
        raise RuntimeError("MANAGED_IDENTITY_CLIENT_ID is not configured.")

    return extract_channel_id(settings.teams_channel_id)


def run_job(settings: Settings) -> dict:
    """Fetch incremental GTI alerts and deliver them to the Teams channel."""
    channel_id = _validate_settings(settings)
    logger.info("Configuration validated. Target channel ID: %s", channel_id)

    team_id = extract_team_id(settings.teams_channel_id)
    if team_id:
        ensure_app_installed(team_id, settings)
    else:
        logger.info(
            "TEAMS_CHANNEL_ID has no groupId (a bare channel ID was given, not the "
            "full link) — skipping Teams app auto-install; the bot must already be "
            "a member of the target team for delivery to succeed."
        )

    cursor = read_cursor(settings)
    if cursor:
        logger.info("Resuming from cursor: %s", cursor)
    else:
        logger.info("No prior state found — fetching entire alert history")

    filter_str = build_filter(cursor, settings)
    logger.info("Alert filter: %s", filter_str)

    newest_str = cursor

    def checkpoint(update_time: str) -> None:
        nonlocal newest_str
        write_cursor(settings, update_time)
        newest_str = update_time
        logger.info("Checkpoint saved: %s", update_time)

    sender = AlertSender(settings, channel_id, on_checkpoint=checkpoint)

    gti_token = get_gti_access_token(settings.gti_api_key)
    logger.info("GTI token acquired. Fetching alerts...")

    count = 0
    for alert in list_alerts(gti_token, settings.gti_rsa_project, filter_str, settings.page_size):
        sender.send(alert)
        count += 1

    logger.info("Done — %d alert(s) sent to Teams channel.", count)
    return {"fetched": count, "cursor_from": cursor, "cursor_to": newest_str}
